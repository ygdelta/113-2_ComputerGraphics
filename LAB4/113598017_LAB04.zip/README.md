113598017 楊挺煜
### LAB04
#### 使用方法
lab04.exe v1.x v1.y v1.z v2.x v2.y v2.z
Ex: lab04.exe 5 10 -5 -5 -10 5
#### 操作方式
- w: $z$ + 0.5
- s: $z$ - 0.5
- d: $x$ + 0.5
- a: $x$ - 0.5
- space: $y$ + 0.5
- c: $y$ - 0.5
- e: $\theta$ + 0.3
- q: $\theta$ - 0.3
- 1, 2, 3: $x,y,z$ 放大
- 4, 5, 6: $x,y,z$ 縮小
- r: reset